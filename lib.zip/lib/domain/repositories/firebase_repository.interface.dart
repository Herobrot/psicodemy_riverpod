/*abstract class FirebaseRepository {
  Future<void> initializeFirebase();
  Future<String?> getToken();
  Future<void> saveTokenToFirestore(String token, String userId);
  Future<void> subscribeToTopic(String topic);
  Future<void> unsubscribeFromTopic(String topic);
  Future<void> handleBackgroundMessage(RemoteMessage message);
  Future<void> handleForegroundMessage(RemoteMessage message);
  Stream<String> onTokenRefresh();
  Future<void> requestPermissions();
}*/