/*abstract class NotificationUseCases {
  Future<void> initializeNotifications();
  Future<void> handleTokenRefresh();
  Future<void> handleForegroundMessage(Map<String, dynamic> message);
  Future<void> handleBackgroundMessage(Map<String, dynamic> message);
  Future<void> subscribeToTopics(List<String> topics);
  Future<void> unsubscribeFromTopics(List<String> topics);
}
import '../repositories/notification_repository_interface.dart';

part 'notification_use_cases.g.dart';


class NotificationUseCases {
  final NotificationRepository _repository;
  
  NotificationUseCases(this._repository);


}*/